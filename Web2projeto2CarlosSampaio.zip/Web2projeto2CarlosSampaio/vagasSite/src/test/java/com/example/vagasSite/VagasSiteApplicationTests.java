package com.example.vagasSite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VagasSiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
