package com.example.vagasSite.model;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.persistence.*;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Entity
@Table(name = "usuario")
public class usuario implements 
//UserDetails,
 Serializable{
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @Column(nullable=false)
    private String nome;
    @Column(nullable=false)
    private String email;
    @Column(nullable=false)
    private long telefone;
    @Column(nullable=false)
    private String tipo;
    @Column(nullable=false,unique = true)
    private long identificacao;
    @Column(nullable=false)
    private String dataNascimento;
    private String img;
    @Column(nullable=false, unique=true)
    private String username;
    @Column(nullable=false)
    private String password;

    // @ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.EAGER)
    // @JoinTable(name = "TB_USERS_ROLES",
    //         joinColumns = @JoinColumn(name = "user_id"),
    //         inverseJoinColumns = @JoinColumn(name = "role_id"))
    // private List<RoleModel> roles;

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public long getTelefone() {
        return telefone;
    }
    public void setTelefone(long telefone) {
        this.telefone = telefone;
    }
    
    public String getDataNascimento() {
        return dataNascimento;
    }
    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }
    public String getImg() {
        return img;
    }
    public void setImg(String img) {
        this.img = img;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public long getIdentificacao() {
        return identificacao;
    }
    public void setIdentificacao(long identificacao) {
        this.identificacao = identificacao;
    }
    
    public usuario(int id, String nome, String email, long telefone, String tipo, long identificacao,
            String dataNascimento, String img, String username, String password
       //     , List<RoleModel> roles
            ) {
        this.id = id;
        this.nome = nome;
        this.email = email;
        this.telefone = telefone;
        this.tipo = tipo;
        this.identificacao = identificacao;
        this.dataNascimento = dataNascimento;
        this.img = img;
        this.username = username;
        this.password = password;
      //  this.roles = roles;
    }
    
    public usuario() {
    }
    
    public usuario orElseThrow(Object object) {
        return null;
    }
    @Override
    public String toString() {
        return "usuario [dataNascimento=" + dataNascimento + ", email=" + email + ", id=" + id + ", identificacao="
                + identificacao + ", img=" + img + ", nome=" + nome + ", password=" + password 
    //            + ", roles="+ roles
                + ", telefone=" + telefone + ", tipo=" + tipo + ", username=" + username + "]";
    }
    // @Override
    // public Collection<? extends GrantedAuthority> getAuthorities() {
    //     return this.roles;
    // }

    // @Override
    // public String getPassword() {
    //     return this.password;
    // }

    // @Override
    // public String getUsername() {
    //     return this.username;
    // }

    // @Override
    // public boolean isAccountNonExpired() {
    //     return true;
    // }

    // @Override
    // public boolean isAccountNonLocked() {
    //     return true;
    // }

    // @Override
    // public boolean isCredentialsNonExpired() {
    //     return true;
    // }

    // @Override
    // public boolean isEnabled() {
    //     return true;
    // }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    public String getUsername() {
        return username;
    }
    public String getPassword() {
        return password;
    }
    
    
}
