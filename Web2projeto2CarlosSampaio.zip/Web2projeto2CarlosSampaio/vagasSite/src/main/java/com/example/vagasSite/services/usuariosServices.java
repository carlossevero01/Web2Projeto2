package com.example.vagasSite.services;

import java.util.List;
import java.util.Optional;

import com.example.vagasSite.model.usuario;

public interface usuariosServices {
    List<usuario> findAll();
    usuario findById(Integer id);
    usuario save(usuario u);
    usuario deleteById(Integer id);
    Optional<usuario> findByUsername(String username);
    List<usuario> findByNomeLike(String nome);
    Optional<usuario> findByIdentificacao(Long identificacao);
}
