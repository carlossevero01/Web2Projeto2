package com.example.vagasSite.enums;


public enum RoleName {
    ROLE_ADMIN,
    ROLE_USER,
    ROLE_EMPRESA;
}

