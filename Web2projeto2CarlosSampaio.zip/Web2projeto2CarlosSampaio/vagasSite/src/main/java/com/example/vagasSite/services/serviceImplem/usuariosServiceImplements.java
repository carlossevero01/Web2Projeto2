package com.example.vagasSite.services.serviceImplem;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.vagasSite.model.usuario;
import com.example.vagasSite.repository.usuariosRepository;
import com.example.vagasSite.services.usuariosServices;

public class usuariosServiceImplements implements usuariosServices{
    @Autowired
    usuariosRepository usuariosRepository;
    @Override
    public List<usuario> findAll() {
        return usuariosRepository.findAll();
    }

    @Override
    public usuario findById(Integer id) {
        return usuariosRepository.findById(id).get();
    }

    @Override
    public usuario save(usuario u) {
        return usuariosRepository.save(u);
    }

    @Override
    public usuario deleteById(Integer id) {
        
        return deleteById(id);
    }
    @Override
    public Optional<usuario> findByUsername(String username){
        return usuariosRepository.findByUsername(username);
    }

    @Override
    public List<usuario> findByNomeLike(String nome) {
        return usuariosRepository.findByNomeLike(nome);
    }

    @Override
    public Optional<usuario> findByIdentificacao(Long identificacao) {
        return usuariosRepository.findByIdentificacao(identificacao);
    }
    
}
