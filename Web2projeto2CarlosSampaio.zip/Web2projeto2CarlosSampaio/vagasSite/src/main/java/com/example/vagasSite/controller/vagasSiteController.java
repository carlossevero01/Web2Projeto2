package com.example.vagasSite.controller;

import java.io.File;
import java.io.IOException;
import java.lang.ProcessBuilder.Redirect;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.annotation.security.PermitAll;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;


import com.example.vagasSite.model.usuario;
import com.example.vagasSite.model.vagaUsuarios;
import com.example.vagasSite.model.vagas;

import com.example.vagasSite.repository.usuariosRepository;
import com.example.vagasSite.repository.vagaUsuariosRepository;
import com.example.vagasSite.repository.vagasRepository;



@Controller
public class vagasSiteController {
    @Autowired
    usuariosRepository uRepository;
    @Autowired
    vagasRepository vRepository;
    @Autowired
    vagaUsuariosRepository vuRepository;
    
    ////////////////////TELA INICIAL////////////////////////////
    
    @RequestMapping(value = "/index", method = RequestMethod.GET)       
    public ModelAndView getVagas(){
        ModelAndView mv = new ModelAndView("index");
        List<vagas> vagasList = vRepository.findAll(); 
        List<usuario> usuariosList = uRepository.findAll();
        mv.addObject("vagas", vagasList);
        mv.addObject("usuarios", usuariosList);
        return mv;
    }
    /////////////////////////////INICIO CADASTROS/////////////////////////////////
    @RequestMapping(value = "/index/cadUsuario",method = RequestMethod.GET)     
    public String insertUsuario(){
        return "cadUsuario";
    }
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_EMPRESA')")
    @RequestMapping(value="/index/cadVaga",method = RequestMethod.GET)
    public ModelAndView insertVaga(){
        ModelAndView mv = new ModelAndView("cadVaga");
        List<usuario> UList = uRepository.findAll();
        mv.addObject("usuarios",UList );
        return mv;
    }
    @RequestMapping(value = "/index/cadUsuario", method= RequestMethod.POST )                   
    public String saveUsuario(@Valid usuario u, BindingResult result, RedirectAttributes attributes, @RequestParam("file") MultipartFile img){
        if(result.hasErrors()){
            attributes.addFlashAttribute("erro","Verifique os campos obrigatórios");
            return "redirect:/index/cadUsuario";
        }
        try {
            if(img.isEmpty()){   
                attributes.addFlashAttribute("erro","Imagem obrigatória não inserido");
                return "redirect:/index/cadUsuario";}
            else{
                byte[] bytes = img.getBytes();
                Path caminho = Paths.get("./src/main/resources/static/images/"+img.getOriginalFilename());
                Files.write(caminho,bytes);
                u.setImg(img.getOriginalFilename());
                u.setPassword(new BCryptPasswordEncoder().encode(u.getPassword()));
                
                //  if(u.getTipo().equals("cpf")){
                //       u.setRoles();}                        // 0 id para admin da tabela tb_roles , 1 user , 2 empresa
                //  else{u.setRoles(2);}                       //ARUMAR AQUI , PEDE TIPO LIST
                uRepository.save(u);
                attributes.addFlashAttribute("sucesso","Cadastro realizado com sucesso");
            }
            
        } catch (Exception e) {System.out.println(e.toString());}
        
        return "redirect:/index";
    }
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_EMPRESA')")        //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    @RequestMapping(value = "/index/cadVaga",method=RequestMethod.POST)
    public String saveVaga(@Valid vagas v, BindingResult result, RedirectAttributes attributes){
        if(v.getVisible()==null){ v.setVisible(false);
        }else{ v.setVisible(true);}

        if(result.hasErrors()){
            attributes.addFlashAttribute("erro","Verifique os campos obrigatórios:"+v.toString());
            return "redirect:/index/cadVaga";
        }
        usuario em = uRepository.findById(v.getIdUsuario()).orElse(null);
        
        if(em!=null){
            vRepository.save(v);
            attributes.addFlashAttribute("sucesso","Disciplina cadastrada");
            return "redirect:/index";
        }
        else{
            attributes.addFlashAttribute("erro"," verifique as caixas marcadas");
            return "redirect:/index/caddisciplina";
        }      
    }
///////////////////////////LISTAR//////////////////////
    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/index/listUsuario", method = RequestMethod.GET)
    public ModelAndView getUsuarios(){
        ModelAndView mv = new ModelAndView("usuarios");
        List<usuario> usuariosList = uRepository.findAll(); 
        mv.addObject("usuarios", usuariosList);
        return mv;
    }
    
    ////////////////////////INICIO DELETAR////////////////////////
    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/index/usuario/delete/{id}", method= RequestMethod.GET )
    public String deleteUsuario(@PathVariable("id") int id, RedirectAttributes attributes){
       try{
        uRepository.deleteById(id);
        attributes.addFlashAttribute("sucesso","Usuario "+id+" deletado");
        return "redirect:/index/listUsuario";
       }catch(Exception e){
        attributes.addFlashAttribute("erro","id inexistente ou erro desconhecido");
        return "redirect:/index/listUsuario";
       } 
    }
    //@PreAuthorize("hasRole('ROLE_ADMIN')")
    @RequestMapping(value = "/index/vaga/delete/{id}", method= RequestMethod.GET )
    public String deleteVaga(@PathVariable("id") int id, RedirectAttributes attributes){
       try{
        vRepository.deleteById(id);
        attributes.addFlashAttribute("sucesso","Vaga "+id+" deletada");
        return "redirect:/index";
       }catch(Exception e){
        attributes.addFlashAttribute("erro","id inexistente ou erro desconhecido");
        return "redirect:/index";
       } 
    }
    //////////////////////////FIM DELETAR/////////////////////////////
    //////////////////////////INICIO UPDATE////////////////////////////
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    @RequestMapping(value = "/index/usuario/update/{id}", method= RequestMethod.GET )                   //Verificação URL, valor = endereço e method = tipo (GET,POST,etc.)
    public ModelAndView updateUsuario(@PathVariable("id") int id){                            //parametro de entrada id, para informar o id do post
        ModelAndView mv = new ModelAndView("updateUsuario");                        //Cria a view HTML
        Optional<usuario> usu =  uRepository.findById(id);                               //Tras a lista de posts
        mv.addObject("nome",usu.get().getNome());
        mv.addObject("email",usu.get().getEmail());
        mv.addObject("telefone",usu.get().getTelefone());
        mv.addObject("tipo",usu.get().getTipo());
        mv.addObject("identificacao",usu.get().getIdentificacao());
        mv.addObject("dataNascimento",usu.get().getDataNascimento());
        mv.addObject("img",usu.get().getImg());
        mv.addObject("username",usu.get().getUsername());
        mv.addObject("password",usu.get().getPassword());
        return mv;
    }
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_EMPRESA')")
    @RequestMapping(value = "/index/vaga/update/{id}", method= RequestMethod.GET )                   
    public ModelAndView updateVaga(@PathVariable("id") int id){                            
        ModelAndView mv = new ModelAndView("updateVaga");                        
        Optional<vagas> vag =  vRepository.findById(id);                               
        mv.addObject("nome",vag.get().getNome());
        mv.addObject("tipo",vag.get().getTipo());
        mv.addObject("idUsuario",vag.get().getIdUsuario());
        mv.addObject("visible",vag.get().getVisible());
        mv.addObject("descricao",vag.get().getDescricao());
        return mv;
    }
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    @RequestMapping(value = "/index/usuario/update/{id}", method= RequestMethod.POST )                   //Verificação URL, valor = endereço e method = POST (GET,POST,etc.) enviar valores para o formulario
    public String saveUpdateUsuario(usuario usuario, RedirectAttributes attributes, @RequestParam("file") MultipartFile img){
        try {
            usuario postExistente = uRepository.findById(usuario.getId()).orElse(null);       
            postExistente.setNome(usuario.getNome());
            postExistente.setEmail(usuario.getEmail());
            postExistente.setTelefone(usuario.getTelefone());
            postExistente.setTipo(usuario.getTipo());
            postExistente.setIdentificacao(usuario.getIdentificacao());
            postExistente.setDataNascimento(usuario.getDataNascimento());
            postExistente.setUsername(usuario.getUsername());
            postExistente.setPassword(usuario.getPassword());
           
            if(img.isEmpty()){   
                attributes.addFlashAttribute("erro","Imagem obrigatória não inserido");
                return "redirect:/index/listUsuario";
            }else{
                byte[] bytes = img.getBytes();
                Path caminho = Paths.get("./src/main/resources/static/images/"+img.getOriginalFilename());
                Files.write(caminho,bytes);
                postExistente.setImg(img.getOriginalFilename());
                uRepository.save(postExistente);
                attributes.addFlashAttribute("sucesso","Post Editado com sucesso ");
                return "redirect:/index/listUsuario";
            }     
        } catch (Exception e) {
            attributes.addFlashAttribute("erro","Não foi possivel editar, confira os campos de texto");
            return "redirect:/index/listUsuario";
        }
    }
    //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_EMPRESA')")
    @RequestMapping(value = "/index/vaga/update/{id}", method= RequestMethod.POST )                   //Verificação URL, valor = endereço e method = POST (GET,POST,etc.) enviar valores para o formulario
    public String saveUpdateVaga(vagas vaga, RedirectAttributes attributes){
        try {
            vagas postExistente = vRepository.findById(vaga.getId()).orElse(null);
            postExistente.setNome(vaga.getNome());
            postExistente.setTipo(vaga.getTipo());
            postExistente.setDescricao(vaga.getDescricao());
            postExistente.setIdUsuario(vaga.getIdUsuario());
            postExistente.setVisible(vaga.getVisible());
            vRepository.save(postExistente);
            attributes.addFlashAttribute("sucesso","Post Editado com sucesso ");
            return "redirect:/index";
            } catch (Exception e) {
            attributes.addFlashAttribute("erro","Não foi possivel editar, confira os campos de texto");
            return "redirect:/index/vaga/update/{id}";
            }
    }
//////////////////////////FIM UPDATE/////////////////////////////
//////////////////////////PESQUISAR//////////////////////////////
    @RequestMapping(value = "/pesquisar", method= RequestMethod.GET )                   
    public ModelAndView getVagasByPesquisa(@RequestParam("pesquisar") String pesquisar){
        ModelAndView mv = new ModelAndView("resultado"); 
        List<usuario> usus = uRepository.findByNomeLike("%"+pesquisar+"%");
        
        List<vagas> vagasResult = new ArrayList<>();
        for(usuario usu : usus){
                vagasResult.addAll(vRepository.findByidUsuario(usu.getId()));
                System.out.println(vagasResult.toString());
        }
        mv.addObject("usuarios", usus);
        mv.addObject("vagas",vagasResult);       
        return mv;
    }
////////////////////////////FIM PESQUISAR//////////////////////////////
////////////////////////////IMAGEM /////////////////////////////////////
    @RequestMapping(value = "index/images/{img}", method = RequestMethod.GET)
    @ResponseBody
    public byte[] getImg(@PathVariable("img") String img) throws IOException{
        File imagemArquivo = new File("./src/main/resources/static/images/"+img);
        if(img != null || img.trim().length()>0){
           
            return Files.readAllBytes(imagemArquivo.toPath());
        }
        
        return null;
    }
    @RequestMapping(value = "/index/vaga/images/{img}", method = RequestMethod.GET)
    @ResponseBody
    public byte[] getImgPost(@PathVariable("img") String img) throws IOException{
        File imagemArquivo = new File("./src/main/resources/static/images/"+img);
        if(img != null || img.trim().length()>0){
           
            return Files.readAllBytes(imagemArquivo.toPath());
        }
        
        return null;
    }
    @RequestMapping(value = "/index/vaga/{id}/images/{img}", method = RequestMethod.GET)
    @ResponseBody
    public byte[] getImgListInscritos(@PathVariable("img") String img) throws IOException{
        File imagemArquivo = new File("./src/main/resources/static/images/"+img);
        if(img != null || img.trim().length()>0){
           
            return Files.readAllBytes(imagemArquivo.toPath());
        }
        
        return null;
    }
    
////////////////////////////FIM IMAGEM//////////////////////////////
////////////////////////////VAGA ID/////////////////////////////////
    @RequestMapping(value = "index/vaga/{id}", method= RequestMethod.GET )                   
    public ModelAndView getVaga(@PathVariable("id") int id){                            
        ModelAndView mv = new ModelAndView("vaga");                        
        Optional<vagas> vaga =  vRepository.findById(id); 
        Optional<usuario> usu = uRepository.findById(vaga.get().getIdUsuario());                              
        mv.addObject("nome",vaga.get().getNome());
        mv.addObject("tipo",vaga.get().getTipo());
        mv.addObject("idUsuario",vaga.get().getIdUsuario());
        mv.addObject("visible",vaga.get().getVisible());
        mv.addObject("id",vaga.get().getId());
        mv.addObject("img",usu.get().getImg());
        mv.addObject("nomeUsu",usu.get().getNome());
        mv.addObject("descricao",vaga.get().getDescricao());
        return mv;
    }
    //////////////////////////////////CANDIDATAR-SE//////////////////////////
    
    
   //@PreAuthorize("hasAnyRole('ROLE_ADMIN','ROLE_USER')")
    @RequestMapping(value="index/vaga/inscreverse/{id}",method=RequestMethod.POST)
   public String getSaveInscreverVaga(@PathVariable("id") int id, @RequestParam Long identificacao, RedirectAttributes attributes){
    try {
        vagaUsuarios vu = new vagaUsuarios();
        vu.setData(LocalDate.now());
        vu.setIdVaga(id);
        Optional<usuario> usu = uRepository.findByIdentificacao(identificacao);
        vu.setIdUsuario(usu.get().getId());         
        vuRepository.save(vu);  
        attributes.addFlashAttribute("sucesso","Inscrito com sucesso ");
        return "redirect:/index";
    } catch (Exception e) {
        attributes.addFlashAttribute("erro","Não foi possivel realizar a inscrição");
        return "index/vaga/inscreverse/{id}";
    }
   }

   @RequestMapping(value = "/index/vaga/{id}/listar", method = RequestMethod.GET)
   public ModelAndView getInscritosPorVaga(@PathVariable("id") int id){
       ModelAndView mv = new ModelAndView("usuarios");
       List<vagaUsuarios> ListvuVaga = vuRepository.findByIdVaga(id);
       List<usuario> usuariosList = new ArrayList<>();
       for (vagaUsuarios vu : ListvuVaga) {
        usuariosList.add(uRepository.findById(vu.getIdUsuario()).get());    
       }
       System.out.println(usuariosList.toString());
       mv.addObject("usuarios", usuariosList);
       return mv;
   }
}
