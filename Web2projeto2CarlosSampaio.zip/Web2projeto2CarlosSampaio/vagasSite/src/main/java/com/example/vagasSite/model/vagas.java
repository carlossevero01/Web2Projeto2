package com.example.vagasSite.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

@Entity
@Table
public class vagas {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;
    @NotNull
    @NotBlank
    private String nome;
    @NotNull
    @NotBlank
    private String tipo;
    @NotBlank
	@Lob
    private String descricao;
    @NotNull
    private int idUsuario;
    
    private Boolean visible;
                                //VERIFICAR SE DA PRA INTERAGIR COM AS TABELAS MANY TO MANY E ADC AQUI e EXCLUIR VAGAS_USUARIOS 
    
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getTipo() {
        return tipo;
    }
    public void setTipo(String tipo) {
        this.tipo = tipo;
    }
    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    public Boolean getVisible() {
        return visible;
    }
    public void setVisible(Boolean visible) {
        this.visible = visible;
    }
    public vagas(@NotBlank String nome, @NotBlank String tipo, @NotBlank int idUsuario,
            @NotBlank Boolean visible) {
        this.nome = nome;
        this.tipo = tipo;
        this.idUsuario = idUsuario;
        this.visible = visible;
    }
    
    @Override
    public String toString() {
        return "vagas [descricao=" + descricao + ", id=" + id + ", idUsuario=" + idUsuario + ", nome=" + nome
                + ", tipo=" + tipo + ", visible=" + visible + "]";
    }
    public vagas() {
    }
    public String getDescricao() {
        return descricao;
    }
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    

}
